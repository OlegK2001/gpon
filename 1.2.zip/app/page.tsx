'use client'

import NetworkCanvas from '@/components/NetworkCanvas'
import Toolbar from '@/components/Toolbar'
import DevicePanel from '@/components/DevicePanel'
import BottomPanel from '@/components/BottomPanel'

export default function Home() {
  return (
    <main className="flex h-screen w-screen bg-gray-900 overflow-hidden flex-col">
      {/* Top Toolbar - Cisco PT style */}
      <Toolbar />
      
      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel - Devices (Cisco PT style) */}
        <DevicePanel />
        
        {/* Main Canvas Area */}
        <div className="flex-1 bg-gray-900">
          <NetworkCanvas />
        </div>
        
        {/* Right Panel - Fixed (formerly Bottom Panel) */}
        <div className="w-96 bg-gray-800 border-l border-gray-700 flex flex-col overflow-hidden">
          <BottomPanel />
        </div>
      </div>
    </main>
  )
}


