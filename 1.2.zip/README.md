# GPON Network Simulator

🎯 **Полнофункциональный аналог Cisco Packet Tracer для GPON сетей**

Визуальный симулятор с эмуляцией работы на всех уровнях OSI, GPON-специфичной логикой и возможностью симуляции атак.

![Interface Style: Cisco Packet Tracer](https://img.shields.io/badge/Style-Cisco_Packet_Tracer-blue)
![Tech: Next.js 14](https://img.shields.io/badge/Tech-Next.js_14-black)
![GPON: Full Support](https://img.shields.io/badge/GPON-Full_Support-green)

## 🚀 Ключевые возможности

### Основной функционал
- **Визуальный редактор сети** - Drag & Drop интерфейс для создания топологии сети
- **Эмуляция GPON устройств** - OLT, ONU, ONT, оптические сплиттеры
- **Традиционные сетевые устройства** - роутеры, коммутаторы, ПК, серверы
- **Симуляция пакетов** - визуализация передачи данных в реальном времени
- **Работа на всех уровнях OSI** - детальная эмуляция от физического до прикладного уровня

### Эмуляция сетевых протоколов
- **Layer 1 (Physical)** - оптические и электрические соединения
- **Layer 2 (Data Link)** - Ethernet, MAC-адресация, VLAN
- **Layer 3 (Network)** - IP-маршрутизация, ARP, ICMP
- **Layer 4 (Transport)** - TCP, UDP
- **Layer 7 (Application)** - HTTP, HTTPS, DNS, FTP

### GPON специфика
- Оптические длины волн (1490nm downstream, 1310nm upstream)
- Бюджет оптической мощности
- Коэффициенты разветвления сплиттеров (1:2, 1:4, 1:8, 1:16, 1:32, 1:64)
- Шифрование GPON
- GEM порты и Alloc-ID

### Симуляция атак
- **DoS/DDoS** - отказ в обслуживании
- **Man-in-the-Middle** - перехват трафика
- **ARP Poisoning** - отравление ARP-таблиц
- **Rogue ONU** - несанкционированное подключение ONU
- **MAC Flooding** - переполнение таблицы MAC-адресов
- **Port Scanning** - сканирование портов
- **Packet Sniffing** - перехват пакетов
- **Unauthorized Access** - попытки несанкционированного доступа

## 📦 Установка

### Требования
- Node.js 18+ 
- npm или yarn

### Установка зависимостей

```bash
npm install
```

### Запуск в режиме разработки

```bash
npm run dev
```

Приложение будет доступно по адресу: [http://localhost:3000](http://localhost:3000)

### Сборка для продакшена

```bash
npm run build
npm start
```

## 🎮 Как использовать

### 1. Создание топологии сети (как в Cisco PT)

1. **Drag & Drop**: Перетащите устройства из левой панели "Device Selection" на белый canvas
2. **Соединение**: Кликайте на синие точки (handles) устройств для создания связей
3. **Выбор**: Кликните на устройство - информация появится в нижней панели Config

### 2. Настройка устройств

Кликните на устройство, затем используйте нижнюю панель:
- **Config Tab** - настройка IP, портов, GPON параметров
- **Console Tab** - просмотр логов и событий
- **Traffic Monitor Tab** - мониторинг пакетов в реальном времени  
- **Security Tab** - запуск и управление атаками

**OLT (Optical Line Terminal):**
- Длины волн upstream/downstream
- Максимальная дистанция
- Шифрование GPON

**ONU/ONT (Optical Network Unit/Terminal):**
- IP-адрес
- MAC-адрес
- Серийный номер

**Router/Switch:**
- IP-адреса интерфейсов
- Таблицы маршрутизации
- VLAN конфигурация
- Firewall правила

### 3. Запуск симуляции

1. Нажмите кнопку **Start** в верхней панели
2. Наблюдайте за передачей пакетов в реальном времени
3. Измените скорость симуляции (0.5x - 8x)
4. Следите за логами в нижней панели

### 4. Симуляция атак (НОВАЯ ФИЧА!)

**Интерактивный режим атак с визуализацией:**

1. Откройте вкладку **Security / Attacks** в нижней панели
2. Выберите тип атаки из списка (DoS, DDoS, MitM, ARP Poisoning, Rogue ONU, и т.д.)
3. Нажмите **Enter Attack Mode**
4. **Шаг 1**: Кликните на устройство-источник атаки (все устройства подсветятся ЗЕЛЕНЫМ пульсирующим эффектом)
5. **Шаг 2**: Кликните на цель атаки (возможные цели подсветятся КРАСНЫМ пульсирующим эффектом)
6. При наведении на цель увидите надпись "🎯 Click to Attack"
7. Атака запустится автоматически и будет отображаться в активных атаках
8. Следите за атакой в Console и Traffic Monitor

**Визуальные подсказки:**
- 🟢 Зеленая пульсация = возможный источник атаки
- 🔴 Красная пульсация = возможная цель атаки  
- ✓ Зеленая рамка = выбранный источник
- 🎯 Красная рамка = наведение на цель

### 5. GPON Регистрация (Автоматическая!)

**Когда вы соединяете ONU/ONT с OLT:**
- ONU автоматически регистрируется на OLT
- Присваивается уникальный ONU ID (отображается в зеленом бейдже на устройстве)
- Генерируется Alloc ID и GEM Port
- В Console появляется сообщение о регистрации
- Статус меняется с "⚠ Not Registered" на "✓ Registered (ID: X)"

### 6. Анализ работы сети

**Config Tab** (нижняя панель) показывает:
- Полную информацию о выбранном устройстве
- Редактируемые поля (IP, имя устройства, статус)
- Статус всех портов с индикацией
- GPON конфигурацию (для OLT)
- GPON регистрацию (для ONU/ONT) с ID, Alloc ID, GEM Port, Serial Number

**Console Tab** отображает:
- Все события в сети в стиле терминала
- Черный фон, цветные логи по уровням (info, warning, error, critical)
- Timestamps и ID устройств
- GPON регистрацию, атаки, пакеты

**Traffic Monitor Tab** показывает:
- Активные пакеты в транзите
- Путь пакета через устройства (с подсветкой текущей позиции)
- Детали Layer 2, 3, 4 (MAC, IP, порты, протоколы)
- GPON Frame данные (ONU ID, Alloc ID, GEM Port)

**Security Tab** позволяет:
- Выбрать и запустить атаку
- Видеть активные атаки с таймерами
- Останавливать атаки
- Анализировать impact атак

## 🏗️ Архитектура

```
├── app/                    # Next.js app directory
│   ├── layout.tsx         # Root layout
│   ├── page.tsx           # Main page
│   └── globals.css        # Global styles
├── components/            # React components
│   ├── NetworkCanvas.tsx  # Main canvas with React Flow
│   ├── Toolbar.tsx        # Top toolbar
│   ├── DevicePanel.tsx    # Left device panel
│   ├── InspectorPanel.tsx # Right inspector
│   ├── SimulationPanel.tsx # Bottom logs
│   ├── AttackPanel.tsx    # Attack controls
│   ├── PacketAnimation.tsx # Packet animation
│   └── nodes/
│       └── DeviceNode.tsx # Custom device node
├── store/                 # State management
│   └── networkStore.ts    # Zustand store
├── types/                 # TypeScript types
│   └── network.ts         # Network types
├── utils/                 # Utilities
│   ├── packetSimulation.ts # Packet logic
│   └── attackSimulation.ts # Attack logic
└── README.md
```

## 🔧 Технологии

- **Next.js 14** - React фреймворк
- **TypeScript** - типизация
- **React Flow** - визуальный редактор графов
- **Zustand** - управление состоянием
- **Tailwind CSS** - стилизация
- **Lucide React** - иконки

## 📚 Примеры топологий

### Базовая GPON топология
```
OLT → Splitter (1:32) → ONU → Router → PC
```

### GPON с множественными абонентами
```
          ┌─ ONU1 → Router1 → PC1
          │
OLT → Splitter ─ ONU2 → Router2 → PC2
          │
          └─ ONU3 → Router3 → PC3
```

### Корпоративная сеть
```
Internet → Router → Switch ─┬─ PC1
                            ├─ PC2
                            ├─ Server
                            └─ Printer
```

## 🐛 Отладка

### Включить подробные логи
Измените уровень логирования в `networkStore.ts`

### Просмотр состояния store
Используйте React DevTools и Zustand DevTools

## 🤝 Вклад в проект

1. Fork репозиторий
2. Создайте feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit изменения (`git commit -m 'Add some AmazingFeature'`)
4. Push в branch (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

## 📝 Roadmap

- [ ] Импорт/Экспорт топологий
- [ ] Больше типов устройств
- [ ] Детальная статистика
- [ ] Автоматическое обнаружение атак
- [ ] Обучающие сценарии
- [ ] Многопользовательский режим
- [ ] 3D визуализация

## 📄 Лицензия

MIT License - свободное использование для образовательных и коммерческих целей

## 👨‍💻 Автор

Создано для обучения и демонстрации работы GPON сетей

## 🙏 Благодарности

- Cisco Packet Tracer за вдохновение
- ITU-T G.984/G.987 спецификации GPON
- React Flow за отличную библиотеку

---

**Примечание:** Это образовательный проект. Симуляция упрощена для демонстрационных целей и не заменяет реальное тестирование оборудования.


