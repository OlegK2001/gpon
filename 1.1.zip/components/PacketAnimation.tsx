'use client'

import { useEffect, useState } from 'react'
import { useNetworkStore } from '@/store/networkStore'
import { Packet } from '@/types/network'
import { PacketSimulator } from '@/utils/packetSimulation'
import { useReactFlow } from 'reactflow'

export default function PacketAnimation() {
  const reactFlowInstance = useReactFlow()
  const { simulation, devices, connections, addPacket, updatePacket, removePacket } = useNetworkStore()
  const [localPackets, setLocalPackets] = useState<Map<string, { x: number; y: number; progress: number }>>(new Map())
  
  // Generate test packets periodically when simulation is running
  useEffect(() => {
    if (!simulation.isRunning || devices.length < 2 || connections.length === 0) return
    
    const interval = setInterval(() => {
      // Find random connected devices
      const connection = connections[Math.floor(Math.random() * connections.length)]
      if (!connection) return
      
      const sourceDevice = devices.find(d => d.id === connection.sourceDeviceId)
      const targetDevice = devices.find(d => d.id === connection.targetDeviceId)
      
      if (!sourceDevice || !targetDevice) return
      
      // Calculate path through network
      const path = PacketSimulator.calculatePath(
        sourceDevice.id,
        targetDevice.id,
        devices,
        connections
      )
      
      if (path.length < 2) return
      
      // Determine if GPON packet
      const isGPON = sourceDevice.type === 'ONU' || sourceDevice.type === 'ONT' || 
                     targetDevice.type === 'ONU' || targetDevice.type === 'ONT' ||
                     sourceDevice.type === 'OLT' || targetDevice.type === 'OLT'
      
      // Create a packet
      const packet: Packet = {
        id: `packet-${Date.now()}-${Math.random()}`,
        type: 'ip',
        source: sourceDevice.id,
        destination: targetDevice.id,
        data: {
          sourceIp: sourceDevice.ipAddress || '0.0.0.0',
          destIp: targetDevice.ipAddress || '0.0.0.0',
          sourceMac: sourceDevice.macAddress || '00:00:00:00:00:00',
          destMac: targetDevice.macAddress || '00:00:00:00:00:00',
          protocol: isGPON ? 'GPON' : 'TCP',
          ttl: 64,
          sourcePort: Math.floor(Math.random() * 60000) + 1024,
          destPort: 80,
          payload: 'Test Data',
        },
        path,
        currentPosition: 0,
        timestamp: Date.now(),
      }
      
      // Add GPON frame data if applicable
      if (isGPON && sourceDevice.config.gponConfig?.onuId) {
        packet.data.gponFrame = {
          onuId: sourceDevice.config.gponConfig.onuId,
          allocId: sourceDevice.config.gponConfig.allocId || 1024,
          gemPort: sourceDevice.config.gponConfig.gemPort || 1280,
        }
      }
      
      addPacket(packet)
      
      // Remove packet after it completes journey (duration depends on speed and path length)
      const duration = (path.length * 1500) / simulation.speed // Slower: 1.5sec per segment
      setTimeout(() => {
        removePacket(packet.id)
      }, duration)
    }, (4000 / simulation.speed)) // Generate packets slower
    
    return () => clearInterval(interval)
  }, [simulation.isRunning, simulation.speed, devices, connections, addPacket, removePacket])
  
  // Animate packets along edges using React Flow's edge positions
  useEffect(() => {
    if (!simulation.isRunning || !reactFlowInstance) return
    
    const interval = setInterval(() => {
      const newPositions = new Map<string, { x: number; y: number; progress: number }>()
      const edges = reactFlowInstance.getEdges()
      
      simulation.packets.forEach(packet => {
        // Calculate total elapsed time
        const elapsed = Date.now() - packet.timestamp
        const segmentDuration = 1500 / simulation.speed // 1.5 seconds per segment adjusted by speed
        
        // Determine which segment we're on
        const totalSegments = packet.path.length - 1
        const currentSegment = Math.floor(elapsed / segmentDuration)
        
        if (currentSegment >= totalSegments) {
          // Packet has reached destination
          return
        }
        
        // Progress within current segment (0 to 1)
        const segmentProgress = (elapsed % segmentDuration) / segmentDuration
        
        const sourceId = packet.path[currentSegment]
        const targetId = packet.path[currentSegment + 1]
        
        // Find the edge between these nodes
        const edge = edges.find(e => 
          (e.source === sourceId && e.target === targetId) ||
          (e.source === targetId && e.target === sourceId)
        )
        
        const sourceNode = reactFlowInstance.getNode(sourceId)
        const targetNode = reactFlowInstance.getNode(targetId)
        
        if (sourceNode && targetNode) {
          // Get actual positions from React Flow (includes zoom and pan)
          const sourcePos = {
            x: sourceNode.position.x + (sourceNode.width || 100) / 2,
            y: sourceNode.position.y + (sourceNode.height || 100) / 2
          }
          
          const targetPos = {
            x: targetNode.position.x + (targetNode.width || 100) / 2,
            y: targetNode.position.y + (targetNode.height || 100) / 2
          }
          
          // Calculate position along the line (straight line for now, React Flow handles curves)
          const x = sourcePos.x + (targetPos.x - sourcePos.x) * segmentProgress
          const y = sourcePos.y + (targetPos.y - sourcePos.y) * segmentProgress
          
          newPositions.set(packet.id, { x, y, progress: segmentProgress })
          
          // Update packet position if moved to next segment
          if (currentSegment !== packet.currentPosition) {
            updatePacket(packet.id, { currentPosition: currentSegment })
          }
        }
      })
      
      setLocalPackets(newPositions)
    }, 16) // 60 FPS
    
    return () => clearInterval(interval)
  }, [simulation.isRunning, simulation.packets, simulation.speed, reactFlowInstance, updatePacket])
  
  const getDeviceName = (id: string) => {
    return devices.find(d => d.id === id)?.name || 'Unknown'
  }
  
  return (
    <>
      {simulation.packets.map(packet => {
        const position = localPackets.get(packet.id)
        if (!position) return null
        
        const isGPON = packet.data.gponFrame !== undefined
        
        return (
          <div key={packet.id} className="absolute pointer-events-none" style={{
            left: `${position.x}px`,
            top: `${position.y}px`,
            transform: 'translate(-50%, -50%)',
            zIndex: 1000,
          }}>
            {/* Packet dot - smaller */}
            <div className={`w-3 h-3 rounded-full shadow-md ${
              isGPON ? 'bg-yellow-400' : 'bg-blue-500'
            } animate-pulse relative`}>
              {/* Glow effect - smaller */}
              <div className={`absolute inset-0 rounded-full ${
                isGPON ? 'bg-yellow-400' : 'bg-blue-500'
              } opacity-40 animate-ping`} />
            </div>
            
            {/* Packet info tooltip - smaller */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-90 text-white px-1.5 py-0.5 rounded whitespace-nowrap pointer-events-none" style={{fontSize: '9px'}}>
              {isGPON && <div className="text-yellow-400 font-bold">GPON</div>}
              <div className="truncate max-w-[120px]">{getDeviceName(packet.source)} → {getDeviceName(packet.destination)}</div>
              {packet.data.gponFrame && (
                <div className="text-yellow-300">
                  ID:{packet.data.gponFrame.onuId}
                </div>
              )}
            </div>
          </div>
        )
      })}
    </>
  )
}
