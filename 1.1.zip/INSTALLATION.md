# 📥 Установка и запуск GPON Network Simulator

## Системные требования

- **Node.js**: версия 18.0 или выше
- **npm**: версия 9.0 или выше (или yarn/pnpm)
- **Браузер**: Chrome, Firefox, Edge (последние версии)
- **ОС**: Windows 10/11, macOS, Linux
- **RAM**: минимум 4 GB
- **Разрешение экрана**: 1920x1080 или выше (рекомендуется)

## Шаг 1: Установка зависимостей

Откройте терминал в папке проекта и выполните:

```bash
npm install
```

Это установит все необходимые пакеты:
- Next.js 14
- React 18
- ReactFlow (для графического редактора)
- Zustand (для state management)
- Tailwind CSS (для стилей)
- Lucide React (для иконок)
- TypeScript

**Ожидаемое время установки:** 2-5 минут в зависимости от скорости интернета.

## Шаг 2: Запуск в режиме разработки

```bash
npm run dev
```

После запуска вы увидите:
```
  ▲ Next.js 14.0.4
  - Local:        http://localhost:3000
  - Network:      http://192.168.x.x:3000

 ✓ Ready in 3.2s
```

Откройте браузер и перейдите по адресу: **http://localhost:3000**

## Шаг 3: Проверка работоспособности

### Проверочный список:
- [ ] Открылась страница с интерфейсом в стиле Cisco PT
- [ ] Видна левая панель "Device Selection" с категориями
- [ ] Белый canvas в центре
- [ ] Верхняя панель с кнопками управления
- [ ] Нижняя панель с вкладками (Config, Console, Traffic Monitor, Security)

### Тест функционала:
1. Перетащите OLT из левой панели на canvas → должен появиться красный квадрат с иконкой
2. Перетащите ONU → должен появиться синий квадрат
3. Соедините их (кликните на синюю точку OLT, затем на синюю точку ONU)
4. Кликните на ONU → в нижней панели Config должна появиться информация
5. В нижней панели Console должно появиться сообщение "ONU registered to OLT"
6. Нажмите "Start" → симуляция должна запуститься

Если все пункты работают - установка успешна! ✅

## Возможные проблемы и решения

### Проблема 1: "Cannot find module 'next'"
**Решение:**
```bash
rm -rf node_modules package-lock.json
npm install
```

### Проблема 2: "Port 3000 already in use"
**Решение:**
```bash
# Запустите на другом порту
npm run dev -- -p 3001
```
Затем откройте http://localhost:3001

### Проблема 3: TypeScript ошибки
**Решение:**
```bash
# Пересоберите TypeScript
npm run build
```

### Проблема 4: Белый экран или ошибки в браузере
**Решение:**
1. Откройте DevTools (F12)
2. Проверьте Console на ошибки
3. Попробуйте очистить кэш браузера (Ctrl+Shift+Delete)
4. Перезапустите dev server

### Проблема 5: React Flow не отображается
**Решение:**
```bash
npm install reactflow@latest --save
npm run dev
```

## Сборка для продакшена

Для создания оптимизированной версии:

```bash
# Сборка
npm run build

# Запуск production сервера
npm start
```

Production версия будет:
- Быстрее загружаться
- Занимать меньше памяти
- Иметь минифицированный код

## Запуск на сервере

### Вариант 1: Локальный сервер
```bash
npm run build
npm start
```
Приложение будет доступно на http://localhost:3000

### Вариант 2: Deploy на Vercel (бесплатно)
```bash
# Установите Vercel CLI
npm i -g vercel

# Deploy
vercel
```
Следуйте инструкциям в терминале.

### Вариант 3: Docker (опционально)
```dockerfile
# Создайте Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
CMD ["npm", "start"]
EXPOSE 3000
```

```bash
docker build -t gpon-simulator .
docker run -p 3000:3000 gpon-simulator
```

## Дополнительные настройки

### Изменение порта по умолчанию

Отредактируйте `package.json`:
```json
{
  "scripts": {
    "dev": "next dev -p 8080"
  }
}
```

### Включение строгого режима TypeScript

В `tsconfig.json` установите:
```json
{
  "compilerOptions": {
    "strict": true
  }
}
```

### Настройка Tailwind CSS

Отредактируйте `tailwind.config.js` для изменения цветовой схемы.

## Обновление зависимостей

Проверить устаревшие пакеты:
```bash
npm outdated
```

Обновить все пакеты:
```bash
npm update
```

Обновить конкретный пакет:
```bash
npm install next@latest
```

## Производительность

### Рекомендуемые настройки браузера:
- Отключите расширения, которые могут замедлять работу
- Включите аппаратное ускорение
- Используйте режим инкогнито для тестирования

### Оптимизация для слабых машин:
- Уменьшите скорость симуляции до 0.5x
- Ограничьте количество устройств (до 20)
- Закройте лишние вкладки браузера

## Разработка

### Структура файлов:
```
├── app/                 # Next.js app directory
│   ├── globals.css     # Глобальные стили
│   ├── layout.tsx      # Root layout
│   └── page.tsx        # Главная страница
├── components/          # React компоненты
├── store/              # Zustand store
├── types/              # TypeScript типы
└── utils/              # Утилиты
```

### Hot Reload
При изменении файлов приложение автоматически перезагрузится.

### Debugging
1. Используйте React DevTools
2. Используйте console.log в компонентах
3. Проверяйте Zustand store в React DevTools

## Полезные команды

```bash
# Запуск dev сервера
npm run dev

# Сборка проекта
npm run build

# Запуск production
npm start

# Линтинг
npm run lint

# Очистка
rm -rf .next node_modules
npm install
```

## Следующие шаги

После успешной установки:
1. Прочитайте [README.md](README.md) для обзора возможностей
2. Изучите [QUICK_START_RU.md](QUICK_START_RU.md) для быстрого старта
3. Попробуйте создать свою первую GPON топологию
4. Экспериментируйте с атаками и мониторингом

---

**Удачной работы с GPON Network Simulator! 🚀**

При возникновении проблем создайте Issue на GitHub или обратитесь к документации Next.js.

